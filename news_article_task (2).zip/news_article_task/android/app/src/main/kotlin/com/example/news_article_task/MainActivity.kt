package com.example.news_article_task

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
