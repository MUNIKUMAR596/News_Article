import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:news_article_task/Bloc.dart/news_bloc_implemenataiton.dart';
import 'package:news_article_task/Bloc.dart/news_stare.dart';
import 'package:news_article_task/article_screeb.dart';

class HomeScreen extends StatelessWidget {
  final List<String> categories = ["General", "Technology", "Sports", "Entertainment"];
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("News App")),
      body: ListView.builder(
        itemCount: categories.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(categories[index]),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => CategoryScreen(category: categories[index].toLowerCase()),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

// Category Screen Implementation
class CategoryScreen extends StatelessWidget {
  final String category;
  
  CategoryScreen({required this.category});
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("$category News")),
      body: BlocBuilder<NewsBloc, NewsState>(
        builder: (context, state) {
          if (state is NewsLoading) {
            return Center(child: CircularProgressIndicator());
          } else if (state is NewsLoaded) {
            return ListView.builder(
              itemCount: state.articles.length,
              itemBuilder: (context, index) {
                final article = state.articles[index];
                return ListTile(
                  leading: Image.network(article.imageUrl, width: 100, fit: BoxFit.cover),
                  title: Text(article.title),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ArticleScreen(article: article),
                      ),
                    );
                  },
                );
              },
            );
          } else {
            return Center(child: Text("Failed to load news"));
          }
        },
      ),
    );
  }
}

