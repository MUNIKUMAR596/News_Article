import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:news_article_task/model.dart';

class ArticleScreen extends StatelessWidget {
  final ArticleModel article;
  
  ArticleScreen({required this.article});
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Article")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(article.imageUrl),
            SizedBox(height: 10),
            Text(article.title, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            SizedBox(height: 10),
            Text(article.content),
          ],
        ),
      ),
    );
  }
}
