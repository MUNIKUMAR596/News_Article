import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:news_article_task/model.dart';
class ApiService {
 // final String baseUrl = " https://newsapi.org/v2/everything?q=tesla&from=2025-03-02&sortBy=publishedAt&apiKey=450e53a34b5a4a55863e83fa61c2a716 ";
 // final String apiKey = "450e53a34b5a4a55863e83fa61c2a716";

  Future<List<ArticleModel>> fetchNews(String category) async {
    final response = await http.get(Uri.parse("https://newsapi.org/v2/everything?q=tesla&from=2025-03-02&sortBy=publishedAt&apiKey=450e53a34b5a4a55863e83fa61c2a716"));
    
    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      
      List<dynamic> articlesJson = data['articles'];
      return articlesJson.map((json) => ArticleModel.fromJson(json)).toList();
    } else {
      throw Exception("Failed to load news");
    }
  }
}
