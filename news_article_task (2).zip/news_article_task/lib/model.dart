class ArticleModel {
  final String title;
  final String imageUrl;
  final String content;

  ArticleModel({required this.title, required this.imageUrl, required this.content});

  factory ArticleModel.fromJson(Map<String, dynamic> json) {
    return ArticleModel(
      title: json['title'] ?? 'No Title',
      imageUrl: json['urlToImage'] ?? '',
      content: json['content'] ?? 'No Content Available',
    );
  }
}
