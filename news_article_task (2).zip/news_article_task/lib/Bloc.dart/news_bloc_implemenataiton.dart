// News Bloc Implementation

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:news_article_task/Api_service.dart';
import 'package:news_article_task/Bloc.dart/news_stare.dart';

import 'news_event.dart';


class NewsBloc extends Bloc<NewsEvent, NewsState> {
  final ApiService apiService;

  NewsBloc({required this.apiService}) : super(NewsLoading()) {
    on<FetchNews>(_onFetchNews);
  }

  Future<void> _onFetchNews(FetchNews event, Emitter<NewsState> emit) async {
    emit(NewsLoading());
    try {
      final articles = await apiService.fetchNews(event.category);
      emit(NewsLoaded(articles: articles));
    } catch (e) {
      emit(NewsError(message: 'Failed to load news'));
    }
  }
}