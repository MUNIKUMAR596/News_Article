import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:news_article_task/Api_service.dart';
import 'package:news_article_task/Bloc.dart/news_bloc_implemenataiton.dart';
import 'package:news_article_task/Bloc.dart/news_event.dart';
import 'package:news_article_task/ui_screen.dart';
// import 'blocs/news_bloc.dart';
// import 'screens/home_screen.dart';
// import 'screens/category_screen.dart';
// import 'services/api_service.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => NewsBloc(apiService: ApiService())..add(FetchNews(category: 'general')),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Flutter News App',
        theme: ThemeData(primarySwatch: Colors.blue),
        home: HomeScreen(),
        routes: {
          '/category': (context) => CategoryScreen(category: '',),
        },
      ),
    );
  }
}
